"""Final finite qualification with tracked documentation held immutable too."""
from pathlib import Path
from datetime import datetime,timezone
import sys,platform,tarfile,io,json,hashlib
ROOT=Path('/Users/artemlegotin/.codex-a/worktrees/1cab/counterexample-guided-operator-coalescing');sys.path.insert(0,str(ROOT))
from provenance.dense_frontier_execution import dense_executed_sources,dense_qualification_specs,dense_execution_env,require_dense_qualification,reference
from provenance.dense_frontier_campaign import read_contract,PROPOSAL
from provenance import sharing_frontier_study as core
from poc.recovery_endpoints import finite_json,verify_refs,write_once
prov=ROOT/'provenance/dense-baseline-expansion-v2';c=read_contract(PROPOSAL);files=dense_executed_sources(PROPOSAL)
review=prov/'review-resolution-v2.json';r=finite_json(review)
if r['status']!='resolved' or r['source_files']!=files or r['unresolved_critical'] or r['unresolved_important']:raise ValueError('resolved reviewed source required')
operation=reference(Path(__file__).resolve());source=prov/'final-source-v3.json';archive=prov/'final-source-v3.tar.gz';environment=prov/'qualification-environment-v3.json'
write_once(source,{'schema_version':1,'files':files,'review':reference(review),'operation':operation,
 'scope':'same reviewed executable source; external source-qualified operation separately archived; tracked docs frozen during tests'})
with archive.open('xb') as stream:
 with tarfile.open(fileobj=stream,mode='w:gz') as tar:
  entries=[(name,digest,str(Path(name).relative_to(ROOT)) if Path(name).is_relative_to(ROOT) else 'installed-source/'+name.lstrip('/')) for name,digest in files.items()]
  if operation['path'] not in files:entries.append((operation['path'],operation['sha256'],'operations/'+Path(operation['path']).name))
  for name,digest,label in entries:
   body=Path(name).read_bytes()
   if hashlib.sha256(body).hexdigest()!=digest:raise ValueError('source changed during final archive')
   info=tarfile.TarInfo(label);info.size=len(body);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(body))
write_once(environment,{'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),
 'scope':'observed environment; CPU/public only, actual native qualification remains separate'})
refs=[{'path':name,'sha256':digest} for name,digest in files.items()]+[reference(PROPOSAL),reference(source),reference(archive),reference(review),reference(environment),operation]
refs +=[reference(ROOT/p) for p in ('README.md','docs/continuation-status-2026-10-31.md','docs/dense-baseline-campaign.md','provenance/continuation-checkpoint-2026-10-31/manifest.json')]
base=Path('/private/tmp/cgoc-dense-final-stable-qualification-v4');base.mkdir(exist_ok=False);stages={}
for name,args,caps in dense_qualification_specs(base):
 output=base/name;output.mkdir(exist_ok=False);command=[sys.executable,*args]
 if name!='public':command.append('--basetemp='+str(output/'pytest'))
 stage=core.execute_stage(command,root=ROOT,output=output,stage=prov/('qualification-'+name+'-v3'),caps=caps,frozen_files=refs,execution_env=dense_execution_env())
 core.require_stage_success(stage);core.check_stage_binding(stage,command=command,root=ROOT,output=output,caps=caps,required_refs=refs,execution_env=dense_execution_env())
 stages[name]={'command':command,'caps':caps,'output':str(output),'stage':stage};print(json.dumps({'stage':name,'status':'accepted'}),flush=True)
q={'schema_version':1,'status':'qualified_dense_source_cpu','study':c['study'],'scientific_contract_sha256':__import__('poc.dense_frontier',fromlist=['dense_contract_digest']).dense_contract_digest(c),
 'proposal':reference(PROPOSAL),'source_manifest':reference(source),'source_archive':reference(archive),'review':reference(review),
 'environment':reference(environment),'operation':operation,'work_root':str(base),'stages':stages}
path=prov/'qualification-v1.json';write_once(path,q);require_dense_qualification(c,proposal_path=PROPOSAL,qualification=reference(path))
print(json.dumps({'status':'qualified source/CPU/public; native and science pending','qualification':reference(path)}),flush=True)
