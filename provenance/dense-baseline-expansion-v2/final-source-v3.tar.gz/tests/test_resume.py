"""Safe immutable generations and exact next-update replay."""
from dataclasses import replace
import importlib
import importlib.util
import json
import random

import numpy as np
import pytest
import torch

from test_training import api, batch, budget, models, MemoryRecorder
from test_records import spec


def bound_config(**changes):
    cfg=api().TrainingConfig(**changes)
    if cfg.run_spec is not None:
        cfg=replace(cfg,run_spec=replace(cfg.run_spec,resolved_config={'training':cfg.identity()}))
    return cfg


def checkpoint():
    assert importlib.util.find_spec('poc.checkpoint'), 'safe checkpoint missing'
    return importlib.import_module('poc.checkpoint')


def test_exact_next_update_replay_all_owned_state(tmp_path):
    t=api(); c=checkpoint(); teacher,student=models()
    cfg=bound_config(max_updates=4,epochs=4,run_spec=spec(budgets=budget()))
    sources=t.TrainingSources(natural=(batch(),))
    first=t.fit_model(student,teacher,sources,replace(cfg,stop_after_updates=2),budget(),MemoryRecorder())
    ref=c.save_checkpoint(first.state,tmp_path)
    saved=c.load_checkpoint(ref,cfg.run_spec)
    assert saved.target_cursor==16 and saved.step==2 and saved.probe_cursor==0
    next_random=(random.random(),float(np.random.random()),torch.rand(3))
    # Both branches restore from the same update boundary, including RNG.
    _,left=models(); _,right=models()
    a=t.fit_model(left,teacher,sources,replace(cfg,resume=saved),budget(),MemoryRecorder(saved.budget_totals))
    draws=(random.random(),float(np.random.random()),torch.rand(3))
    b=t.fit_model(right,teacher,sources,replace(cfg,resume=c.load_checkpoint(ref,cfg.run_spec)),budget(),MemoryRecorder(saved.budget_totals))
    assert random.random()==draws[0] and float(np.random.random())==draws[1]
    assert torch.equal(torch.rand(3),draws[2])
    for n,p in left.named_parameters(): assert torch.equal(p,dict(right.named_parameters())[n])
    assert a.state.target_cursor==b.state.target_cursor==32
    assert a.state.scheduler==b.state.scheduler
    assert a.state.events==b.state.events
    for n,values in a.state.optimizer['state'].items():
        for key,value in values.items():
            other=b.state.optimizer['state'][n][key]
            assert torch.equal(value,other) if isinstance(value,torch.Tensor) else value==other
    assert saved.order==a.state.order and saved.probe_order==a.state.probe_order
    assert next_random[0]!=random.random()


@pytest.mark.parametrize('point',['before_generation_publish','after_generation_publish','before_pointer_replace','after_pointer_replace'])
def test_crash_publication_keeps_current_or_previous_verified_generation(tmp_path,monkeypatch,point):
    t=api();c=checkpoint();teacher,student=models(); identity=spec(budgets=budget())
    cfg=bound_config(max_updates=2,epochs=2,run_spec=identity);identity=cfg.run_spec
    state=t.fit_model(student,teacher,t.TrainingSources(natural=(batch(),)),replace(cfg,stop_after_updates=1),budget(),MemoryRecorder()).state
    first=c.save_checkpoint(state,tmp_path)
    def crash(stage):
        if stage==point: raise InterruptedError(point)
    monkeypatch.setattr(c,'_publication_boundary',crash)
    with pytest.raises(InterruptedError): c.save_checkpoint(state,tmp_path)
    current=c.resolve_checkpoint(tmp_path)
    assert c.load_checkpoint(current,identity).step==1
    assert (tmp_path/'current.json').exists()
    assert c.load_checkpoint(first,identity).candidate_digest==state.candidate_digest


def test_corrupt_newest_explicit_fallback_and_changed_lineage(tmp_path):
    t=api();c=checkpoint();teacher,student=models(); identity=spec(budgets=budget())
    cfg=bound_config(max_updates=1,run_spec=identity);identity=cfg.run_spec
    state=t.fit_model(student,teacher,t.TrainingSources(natural=(batch(),)),cfg,budget(),MemoryRecorder()).state
    old=c.save_checkpoint(state,tmp_path);new=c.save_checkpoint(state,tmp_path)
    tensor_path=__import__('pathlib').Path(new.directory)/'tensors.safetensors'
    tensor_path.write_bytes(tensor_path.read_bytes()+b'corrupt')
    with pytest.raises(ValueError,match='hash'): c.load_checkpoint(new,identity)
    with pytest.raises(ValueError): c.resolve_checkpoint(tmp_path)
    fallback=c.resolve_checkpoint(tmp_path,fallback_previous=True)
    assert fallback==old
    for mismatch in [replace(identity,dependency_lock_sha256='e'*64),replace(identity,input_manifests={'new':'f'*64}),replace(identity,resolved_config={'map':[0,0,0]})]:
        with pytest.raises(ValueError,match='lineage'): c.load_checkpoint(old,mismatch)
    assert not list(tmp_path.rglob('*.pt')) and not list(tmp_path.rglob('*.pkl'))


def test_restore_rejects_invalid_optimizer_without_mutating_model(tmp_path):
    from copy import deepcopy
    t=api();teacher,student=models();identity=spec(budgets=budget())
    cfg=bound_config(max_updates=2,epochs=2,run_spec=identity);identity=cfg.run_spec
    sources=t.TrainingSources(natural=(batch(),))
    state=t.fit_model(student,teacher,sources,replace(cfg,stop_after_updates=1),budget(),MemoryRecorder()).state
    _,fresh=models();before={n:p.clone() for n,p in fresh.named_parameters()}
    bad=replace(state,optimizer=deepcopy(state.optimizer));bad.optimizer['groups'][0]['owner_ids']=['wrong']
    with pytest.raises(ValueError,match='optimizer'):
        t.fit_model(fresh,teacher,sources,replace(cfg,resume=bad),budget(),MemoryRecorder(state.budget_totals))
    assert all(torch.equal(p,before[n]) for n,p in fresh.named_parameters())


def test_actual_fitted_checkpoint_export_resolves_identity_and_weights(tmp_path,capsys):
    from poc.cli import main
    from poc.records import start_attempt
    from poc.bundle import load_bundle
    from poc.contracts import thaw
    from test_export import runtime
    t=api();c=checkpoint();teacher,student=models();teacher=teacher.float();student=student.float()
    cfg=bound_config(max_updates=1,run_spec=spec(budgets=budget()),kl_floor_per_target=1e-6,numerical_profile='fixture_fp32')
    identity=cfg.run_spec;attempt=start_attempt(identity,tmp_path/'runs')
    fitted=t.fit_model(student,teacher,t.TrainingSources(natural=(batch(),)),cfg,budget(),MemoryRecorder())
    ref=c.save_checkpoint(fitted.state,attempt.path/'checkpoints')
    run_runtime=runtime(tmp_path);runtime_path=tmp_path/'runtime.json'
    from dataclasses import asdict
    runtime_path.write_text(json.dumps({f.name:thaw(getattr(run_runtime,f.name)) for f in __import__('dataclasses').fields(run_runtime)}))
    assert main(['export','--run-root',str(tmp_path/'runs'),'--run',attempt.run_id,'--attempt',attempt.attempt_id,
        '--runtime-spec',str(runtime_path),'--out',str(tmp_path/'fitted-bundle')])==0
    receipt=json.loads((tmp_path/'fitted-bundle.receipt.json').read_text())
    assert receipt['fitted_checkpoint_resolved'] is True and receipt['run_id']==attempt.run_id
    assert receipt['checkpoint_manifest_sha256']==ref.manifest_sha256
    loaded=load_bundle(tmp_path/'fitted-bundle',backend='torch')
    torch.testing.assert_close(loaded.logits(batch()),student.logits(batch()),rtol=0,atol=0)
    assert main(['export','--run-root',str(tmp_path/'runs'),'--run','a'*64,'--attempt',attempt.attempt_id,
        '--runtime-spec',str(runtime_path),'--out',str(tmp_path/'wrong')])==4


def test_local_probe_cursor_and_live_candidate_provenance_replay(tmp_path):
    from test_training import local_sources
    t=api();c=checkpoint();teacher,student=models();identity=spec(budgets=budget())
    sources=local_sources(teacher,student)
    cfg=bound_config(max_updates=4,epochs=4,phase='local',affected_depths=(0,1),
        mixture_weights={'natural':.5,'student':.25,'donor':.25},run_spec=identity)
    identity=cfg.run_spec
    first=t.fit_model(student,teacher,sources,replace(cfg,stop_after_updates=2),budget(),MemoryRecorder())
    ref=c.save_checkpoint(first.state,tmp_path)
    _,resumed=models()
    restored=t.fit_model(resumed,teacher,local_sources(teacher,resumed),replace(cfg,resume=c.load_checkpoint(ref,identity)),budget(),MemoryRecorder(first.state.budget_totals))
    _,whole=models();uninterrupted=t.fit_model(whole,teacher,local_sources(teacher,whole),cfg,budget(),MemoryRecorder())
    assert restored.state.probe_cursor==uninterrupted.state.probe_cursor==12
    assert restored.state.target_cursor==uninterrupted.state.target_cursor==40
    for n,p in whole.named_parameters():assert torch.equal(p,dict(resumed.named_parameters())[n])
    assert restored.state.events==uninterrupted.state.events


def test_truncated_cost_tail_is_preserved_and_blocks_resume(tmp_path):
    from poc.records import start_attempt,RecordError
    from poc.budget import BudgetTracker
    t=api();teacher,student=models();identity=spec(budgets=budget());attempt=start_attempt(identity,tmp_path)
    tracker=BudgetTracker(identity.budgets,attempt);tracker.record(__import__('poc.contracts',fromlist=['CostRecord']).CostRecord(wall_seconds=1))
    with tracker.path.open('ab') as stream:stream.write(b'{"event_id":2')
    tail=tracker.path.read_bytes()
    with pytest.raises(RecordError,match='truncated'):
        t.fit_model(student,teacher,t.TrainingSources(natural=(batch(),)),t.TrainingConfig(max_updates=1),budget(),tracker)
    assert tracker.path.read_bytes()==tail


def test_only_last_and_previous_published_generations_are_retained(tmp_path):
    t=api();c=checkpoint();teacher,student=models();identity=spec(budgets=budget())
    cfg=bound_config(max_updates=1,run_spec=identity);identity=cfg.run_spec
    state=t.fit_model(student,teacher,t.TrainingSources(natural=(batch(),)),cfg,budget(),MemoryRecorder()).state
    a=c.save_checkpoint(state,tmp_path);b=c.save_checkpoint(state,tmp_path);last=c.save_checkpoint(state,tmp_path)
    from pathlib import Path
    assert not Path(a.directory).exists()
    assert Path(b.directory).exists() and Path(last.directory).exists()
    assert len(list(tmp_path.glob('generation-*')))==2


def test_global_reference_replay_matches_uninterrupted_four_updates(tmp_path):
    t=api();c=checkpoint();teacher,whole=models();identity=spec(budgets=budget())
    cfg=bound_config(max_updates=4,epochs=4,run_spec=identity);identity=cfg.run_spec;sources=t.TrainingSources(natural=(batch(),))
    full=t.fit_model(whole,teacher,sources,cfg,budget(),MemoryRecorder())
    _,partial=models();first=t.fit_model(partial,teacher,sources,replace(cfg,stop_after_updates=2),budget(),MemoryRecorder())
    ref=c.save_checkpoint(first.state,tmp_path);_,resumed=models()
    after=t.fit_model(resumed,teacher,sources,replace(cfg,resume=c.load_checkpoint(ref,identity)),budget(),MemoryRecorder(first.state.budget_totals))
    for n,p in whole.named_parameters():assert torch.equal(p,dict(resumed.named_parameters())[n])
    assert full.state.events==after.state.events and full.state.visited==after.state.visited
    assert full.state.scheduler==after.state.scheduler


@pytest.mark.mps
def test_owned_mps_fp32_next_update_checkpoint_replay(tmp_path):
    assert torch.backends.mps.is_available()
    t=api();c=checkpoint();teacher,student=models();teacher=teacher.float().to('mps');student=student.float().to('mps')
    b=batch();b=replace(b,**{n:getattr(b,n).to('mps') for n in ('input_ids','attention_mask','target_mask','positions')})
    sources=t.TrainingSources(natural=(b,))
    cfg=bound_config(max_updates=4,epochs=4,run_spec=spec(budgets=budget()),kl_floor_per_target=1e-6,numerical_profile='owned_tiny_mps_fp32')
    first=t.fit_model(student,teacher,sources,replace(cfg,stop_after_updates=2),budget(),MemoryRecorder())
    ref=c.save_checkpoint(first.state,tmp_path)
    continued=t.fit_model(student,teacher,sources,replace(cfg,resume=first.state),budget(),MemoryRecorder(first.state.budget_totals))
    _,other=models();other=other.float().to('mps')
    replayed=t.fit_model(other,teacher,sources,replace(cfg,resume=c.load_checkpoint(ref,cfg.run_spec)),budget(),MemoryRecorder(first.state.budget_totals))
    for n,p in student.named_parameters():torch.testing.assert_close(p,dict(other.named_parameters())[n],rtol=0,atol=0)
    assert continued.state.events==replayed.state.events and continued.state.target_cursor==replayed.state.target_cursor==32
    assert continued.state.scheduler==replayed.state.scheduler
    assert torch.equal(continued.state.rng['mps'],replayed.state.rng['mps'])
    for n,moments in continued.state.optimizer['state'].items():
        for k,v in moments.items():
            other_value=replayed.state.optimizer['state'][n][k]
            assert torch.equal(v,other_value) if isinstance(v,torch.Tensor) else v==other_value


def test_pointer_previous_cannot_escape_checkpoint_root_during_pruning(tmp_path):
    from pathlib import Path
    t=api();c=checkpoint();teacher,student=models();cfg=bound_config(max_updates=1,run_spec=spec(budgets=budget()))
    state=t.fit_model(student,teacher,t.TrainingSources(natural=(batch(),)),cfg,budget(),MemoryRecorder()).state
    victim=c.save_checkpoint(state,tmp_path/'outside');c.save_checkpoint(state,tmp_path/'root')
    pointer=tmp_path/'root'/'current.json';raw=json.loads(pointer.read_text())
    raw['previous']={'generation':'../outside/'+Path(victim.directory).name,'manifest_sha256':victim.manifest_sha256};pointer.write_text(json.dumps(raw))
    with pytest.raises(ValueError,match='pointer'):c.save_checkpoint(state,tmp_path/'root')
    assert Path(victim.directory).exists()


@pytest.mark.parametrize('field,value',[
    ('scheduler',{'completed_updates':999}),('step',999),('target_cursor',17),('probe_cursor',1),
    ('order',(('other-doc',),)),('probe_order',('other-probe',)),('visited',()),
])
def test_resume_rejects_inconsistent_recovery_metadata_before_tensor_mutation(field,value):
    t=api();teacher,student=models();cfg=bound_config(max_updates=4,epochs=4,run_spec=spec(budgets=budget()))
    sources=t.TrainingSources(natural=(batch(),))
    first=t.fit_model(student,teacher,sources,replace(cfg,stop_after_updates=2),budget(),MemoryRecorder())
    _,fresh=models();before={n:p.clone() for n,p in fresh.named_parameters()}
    bad=replace(first.state,**{field:value})
    with pytest.raises(ValueError,match='recovery|scheduler|cursor|order|visited|step'):
        t.fit_model(fresh,teacher,sources,replace(cfg,resume=bad),budget(),MemoryRecorder(first.state.budget_totals))
    assert all(torch.equal(p,before[n]) for n,p in fresh.named_parameters())


@pytest.mark.mps
def test_mps_checkpoint_reconstructs_portably_and_preserves_exact_source_identity(tmp_path):
    t=api();c=checkpoint();teacher,student=models();teacher=teacher.float().to('mps');student=student.float().to('mps')
    b=batch();b=replace(b,**{n:getattr(b,n).to('mps') for n in ('input_ids','attention_mask','target_mask','positions')})
    cfg=bound_config(max_updates=1,run_spec=spec(budgets=budget()),kl_floor_per_target=1e-6,numerical_profile='owned_tiny_mps_fp32')
    fitted=t.fit_model(student,teacher,t.TrainingSources(natural=(b,)),cfg,budget(),MemoryRecorder())
    ref=c.save_checkpoint(fitted.state,tmp_path);state=c.load_checkpoint(ref,cfg.run_spec)
    reconstructed=c.checkpoint_decoder(state)
    assert reconstructed.device.type=='cpu'
    for name,p in student.named_parameters():assert torch.equal(p.cpu(),dict(reconstructed.named_parameters())[name])
    assert reconstructed.to('mps').manifest().checkpoint_digest==state.candidate_digest
    legacy=replace(state,model_schema={k:v for k,v in state.model_schema.items() if k!='device'})
    assert c.checkpoint_decoder(legacy).to('mps').manifest().checkpoint_digest==state.candidate_digest


def assert_recovery_tree_equal(actual, expected):
    """Compare protected recovery values, including backend and NumPy RNGs."""
    if isinstance(expected,torch.Tensor):
        assert actual.dtype==expected.dtype and actual.device==expected.device
        assert torch.equal(actual,expected)
    elif isinstance(expected,np.ndarray):
        assert actual.dtype==expected.dtype
        np.testing.assert_array_equal(actual,expected)
    elif isinstance(expected,dict):
        assert actual.keys()==expected.keys()
        for key in expected:assert_recovery_tree_equal(actual[key],expected[key])
    elif isinstance(expected,(tuple,list)):
        assert type(actual) is type(expected) and len(actual)==len(expected)
        for a,b in zip(actual,expected,strict=True):assert_recovery_tree_equal(a,b)
    else:assert actual==expected


def recovery_rejection_fixture(*,device='cpu',phase='global'):
    """Real caller optimizer/history deliberately differ from the saved state."""
    from copy import deepcopy
    from test_training import local_sources
    t=api();teacher,student=models()
    if device=='mps':teacher=teacher.float().to(device);student=student.float().to(device)
    b=batch()
    if device=='mps':b=replace(b,**{n:getattr(b,n).to(device) for n in ('input_ids','attention_mask','target_mask','positions')})
    kwargs={} if phase=='global' else dict(phase='local',affected_depths=(0,1),mixture_weights={'natural':.5,'student':.25,'donor':.25})
    cfg=bound_config(max_updates=3,epochs=3,run_spec=spec(budgets=budget()),
        **kwargs,**({} if device=='cpu' else dict(kl_floor_per_target=1e-6,numerical_profile='owned_tiny_mps_fp32')))
    sources=t.TrainingSources(natural=(b,)) if phase=='global' else local_sources(teacher,student)
    saved=t.fit_model(student,teacher,sources,replace(cfg,stop_after_updates=1),budget(),MemoryRecorder()).state
    _,caller=models()
    if device=='mps':caller=caller.float().to(device)
    owners=t.configure_trainable_owners(caller,cfg,apply=False);optimizer=t._optimizer(owners,cfg)
    caller.logits(b).square().sum().backward();optimizer.step();optimizer.zero_grad(set_to_none=True)
    for group in optimizer.param_groups:group['lr']*=.37
    caller.train();caller.layers[0].eval()
    next(iter(owners.values())).requires_grad_(False)
    return t,teacher,caller,optimizer,cfg,sources,saved


def assert_recovery_rejection_preserves_caller(fixture,bad,*,match):
    from copy import deepcopy
    from dataclasses import fields
    t,teacher,caller,optimizer,cfg,sources,_=fixture
    before_parameters={n:p.detach().clone() for n,p in caller.named_parameters()}
    before_flags={n:p.requires_grad for n,p in caller.named_parameters()}
    before_modes={n:m.training for n,m in caller.named_modules()}
    before_optimizer=deepcopy(optimizer.state_dict());before_rng=deepcopy(t._rng())
    def saved_values():
        return {f.name:(bad.spec.to_dict() if f.name=='spec' else getattr(bad,f.name)) for f in fields(bad)}
    before_saved=deepcopy(saved_values())
    with pytest.raises(ValueError,match=match):
        t._restore(bad,caller,optimizer,cfg,sources,teacher.manifest().checkpoint_digest)
    assert_recovery_tree_equal({n:p.detach() for n,p in caller.named_parameters()},before_parameters)
    assert {n:p.requires_grad for n,p in caller.named_parameters()}==before_flags
    assert {n:m.training for n,m in caller.named_modules()}==before_modes
    assert_recovery_tree_equal(optimizer.state_dict(),before_optimizer)
    assert_recovery_tree_equal(t._rng(),before_rng)
    assert_recovery_tree_equal(saved_values(),before_saved)


@pytest.mark.parametrize('corruption',['negative_second_moment','step_zero','step_negative','step_fractional','step_future','step_stale_global','missing_global_moments'])
def test_adam_semantic_rejection_preserves_all_caller_and_saved_state(corruption):
    from copy import deepcopy
    fixture=recovery_rejection_fixture()
    t,teacher,student,_,cfg,sources,saved=fixture
    # The stale-count case needs two completed global updates.
    if corruption=='step_stale_global':
        _,trained=models()
        saved=t.fit_model(trained,teacher,sources,replace(cfg,stop_after_updates=2),budget(),MemoryRecorder()).state
    bad=replace(saved,optimizer=deepcopy(saved.optimizer))
    name=next(n for n,m in bad.optimizer['state'].items() if m)
    moments=bad.optimizer['state'][name]
    if corruption=='negative_second_moment':moments['exp_avg_sq'].fill_(-1)
    elif corruption=='missing_global_moments':bad.optimizer['state'][name]={}
    else:
        values={'step_zero':0,'step_negative':-1,'step_fractional':.5,'step_future':saved.step+1,'step_stale_global':1}
        moments['step'].fill_(values[corruption])
    assert_recovery_rejection_preserves_caller(fixture,bad,match='optimizer')


def test_local_recovery_keeps_legitimate_unused_owner_empty_state():
    from test_training import local_sources
    t=api();teacher,student=models();sources=local_sources(teacher,student)
    cfg=bound_config(max_updates=3,epochs=3,phase='local',affected_depths=(0,1),
        mixture_weights={'natural':.5,'student':.25,'donor':.25},run_spec=spec(budgets=budget()))
    first=t.fit_model(student,teacher,sources,replace(cfg,stop_after_updates=1),budget(),MemoryRecorder())
    unused={n for n,m in first.state.optimizer['state'].items() if not m}
    assert unused and all(n.startswith('layers.0.mlp.residuals.') for n in unused)
    _,resumed=models()
    result=t.fit_model(resumed,teacher,local_sources(teacher,resumed),replace(cfg,resume=first.state),budget(),MemoryRecorder(first.state.budget_totals))
    assert result.state.step==3
    assert all(result.state.optimizer['state'][n]=={} for n in unused)


@pytest.mark.parametrize('mutation',['missing_python','missing_numpy','missing_torch','unexpected_backend'])
def test_complete_rng_schema_rejection_preserves_all_state(mutation):
    from copy import deepcopy
    fixture=recovery_rejection_fixture();saved=fixture[-1];rng=deepcopy(saved.rng)
    if mutation.startswith('missing_'):rng.pop(mutation.removeprefix('missing_'))
    else:rng['cuda']=torch.zeros(1,dtype=torch.uint8)
    assert_recovery_rejection_preserves_caller(fixture,replace(saved,rng=rng),match='RNG')


@pytest.mark.mps
def test_mps_recovery_requires_backend_rng_before_any_caller_mutation():
    from copy import deepcopy
    assert torch.backends.mps.is_available()
    fixture=recovery_rejection_fixture(device='mps');saved=fixture[-1]
    rng=deepcopy(saved.rng);assert 'mps' in rng;rng.pop('mps')
    assert_recovery_rejection_preserves_caller(fixture,replace(saved,rng=rng),match='RNG')


@pytest.mark.mps
def test_cpu_recovery_on_mps_host_preserves_optional_captured_mps_rng():
    assert torch.backends.mps.is_available()
    fixture=recovery_rejection_fixture();t,teacher,caller,_,cfg,sources,saved=fixture
    assert saved.model_schema['backend']=='torch_cpu' and 'mps' in saved.rng
    torch.mps.manual_seed(918)
    result=t.fit_model(caller,teacher,sources,replace(cfg,resume=saved,stop_after_updates=1),budget(),MemoryRecorder(saved.budget_totals))
    assert torch.equal(result.state.rng['mps'],saved.rng['mps'])
    assert result.state.step==2
